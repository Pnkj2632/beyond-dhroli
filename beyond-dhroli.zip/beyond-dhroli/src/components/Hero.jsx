
export default function Hero() {
  return (
    <section style={{
      minHeight:'80vh',
      display:'flex',
      alignItems:'center',
      justifyContent:'center',
      textAlign:'center',
      padding:'40px'
    }}>
      <div>
        <h1 style={{fontSize:'60px'}}>Explore Beyond Limits</h1>
        <p style={{fontSize:'20px',color:'#cbd5e1'}}>
          AI-powered travel planning with modern UI.
        </p>
        <button style={{
          marginTop:'20px',
          padding:'15px 30px',
          border:'none',
          borderRadius:'12px',
          background:'#38bdf8',
          color:'black',
          fontWeight:'bold'
        }}>
          Start Planning
        </button>
      </div>
    </section>
  )
}
