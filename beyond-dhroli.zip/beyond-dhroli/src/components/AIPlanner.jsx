
export default function AIPlanner() {
  return (
    <section style={{padding:'60px 20px'}}>
      <div style={{
        maxWidth:'700px',
        margin:'auto',
        background:'rgba(255,255,255,0.1)',
        padding:'40px',
        borderRadius:'24px'
      }}>
        <h2 style={{fontSize:'40px'}}>AI Travel Planner</h2>
        <input
          placeholder="Example: Goa trip under ₹20,000"
          style={{
            width:'100%',
            padding:'16px',
            marginTop:'20px',
            borderRadius:'12px'
          }}
        />
        <button style={{
          marginTop:'20px',
          padding:'15px 25px',
          border:'none',
          borderRadius:'12px',
          background:'#38bdf8',
          fontWeight:'bold'
        }}>
          Generate Plan
        </button>
      </div>
    </section>
  )
}
