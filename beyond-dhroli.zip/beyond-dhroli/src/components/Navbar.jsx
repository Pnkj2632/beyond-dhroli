
export default function Navbar() {
  return (
    <nav style={{
      display:'flex',
      justifyContent:'space-between',
      padding:'20px 40px',
      background:'rgba(255,255,255,0.1)',
      backdropFilter:'blur(10px)'
    }}>
      <h1 style={{color:'#38bdf8'}}>Beyond Dhroli</h1>
      <div style={{display:'flex',gap:'20px'}}>
        <a href="#" style={{color:'white'}}>Home</a>
        <a href="#" style={{color:'white'}}>Destinations</a>
        <a href="#" style={{color:'white'}}>Contact</a>
      </div>
    </nav>
  )
}
