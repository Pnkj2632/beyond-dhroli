
export default function Footer() {
  return (
    <footer style={{
      textAlign:'center',
      padding:'30px',
      marginTop:'40px',
      background:'black'
    }}>
      <p>© 2026 Beyond Dhroli</p>
    </footer>
  )
}
