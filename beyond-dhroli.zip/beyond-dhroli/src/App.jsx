
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import AIPlanner from "./components/AIPlanner";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div>
      <Navbar />
      <Hero />
      <AIPlanner />
      <Footer />
    </div>
  );
}
